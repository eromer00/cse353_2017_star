Group Members:

* Erik Romero
* Erik Garcia
* Steven Ramsey
* Tyler Shellberg

GIT LOG STATISTICS:
	* Each member had their own branch in git, here's the number of commits/changes per member:
	* Erik Romero - 63 commits, 1912 additions
	* Erik Garcia - 74 commits, 1924 additions
	* Steven Ramsey - 56 commits, 2016 additions
	* Tyler Shellberg - 64 commits, 761 additions

	Work was divided fairly evenly, but Steven put the most work into this
	
Compilation Instructions:

Compilation can be done via the Makefile provided along with this assignment. Calling "make all" in the terminal when 
in a directory with the Makefile and source code present will perform the compilation.

Execution Instructions:

Simply called "java Main" in the directory with the compiled .class files for this project.
Default .class files will be included as well

Files:

Main.java 	- The main class, which instantiates the switch and all nodes, as well as performing cleanup.
Frame.java 	- Implements a custom frame format
Node.java 	- Implements a generic node, which can be generated and connected to a CASSwitch
NodeListener.java - listens for incoming data into the node
MonitorNode.java - sets up a monitor to handle frames which never get acknowledged
RelayNode.java - sends back frame data resulting from MonitorNode.java
CASSwitch.java 	- Implements a switch which can connect up to 16 nodes to allow for their communication, and buffers frames if needed. 
CASListenerThread.java - handles all incoming frames into CAS switch
CCSSwitch.java 	- Implements a switch which can connect up to 16 CAS switches to allow for their communication, and buffers frames if needed. 
CCSListenerThread.java - handles all incoming frames into CCS switch
Makefile	- Build automation
README 		- Documentation for this project, including compilation instructions

Feature Checklist:

Feature 											| Status/Description 	| 
-----------------------------------------------------------------------------------------
Project Compiles and Builds without warnings or errors						complete
Switch class 																complete
CAS, CCS Switches has a frame queue, and reads/writes appropriately			complete
CAS, CCS Switches allows multiple connections								complete
CAS, CCS Switches floods frame when it doesn't know the destination			complete
CAS, CCS Switches learns destinations, and doesn't forward packet 
to any port except the one required 										complete
CAS make connection to CCS													complete
CAS receive the local firewall rules										complete
CAS send AC=00 back															partial - sends but is never properly received
CAS forward the traffic and ACK properly									complete
CCSswitch opens the firewall file and get the rules							complete
CCSpasses global traffic 													complete
CCSdoes the global firewalls												complete
CCSsend AC=00 back.															Partial - sends but is never properly received
CCS Shadow switches run and test properly									Complete
Node class																	Partially Complete –see below
Nodes instantiate, and open connection to the switch						complete
Nodes open their input files, and send data to switch.						complete
Nodes open their output files, and save data that they received				Complete
Node will sometimes drop  acknowledgment									Complete - node dropping is done in the CASSwitch,
																			but functionality is the same
Node will sometimes create erroneous frame									complete
Node will sometimes reject traffic											Complete - frame rejection is done in the CASSwitch,
																			but functionality is the same

Known Bugs:

Frames may be dropped
ACK doesn't properly stall nodes from sending
Firewall may allow data in that shouldn't be allowed
All ports may not be properly closed on exit
